# sol_fixed.py
#
# Ransomatrix 복호화 시도 코드
# ------------------------------------------------------------
# 전제:
# 1) 원본 파일은 PNG이고 첫 바이트 0x89가 srand(seed)에 사용된다.
# 2) rand()/srand()는 MSVC/UCRT 계열 동작을 따른다고 가정한다.
# 3) 암호문은 블록당 98바이트:
#       49개 행렬 원소 × 각 원소의 하위 2바이트
# 4) 행렬 연산은 mod 65413에서 수행된다.
#
# 핵심 수정점:
# - sub_16A0에서 rand()는
#     [i번째 suffix 행렬곱용 rand 소비] -> [i번째 출력 XOR용 rand 소비]
#   순서로 섞여서 호출된다.
#   따라서 모든 행렬곱용 rand()를 한 번에 먼저 소비하면 안 된다.
#
# - C 코드:
#       *(_BYTE *)(...) = rand() ^ v6;
#   는 최종 저장 대상이 1바이트이므로,
#   복호화 시 rand()의 하위 8비트만 XOR해야 한다.
# ------------------------------------------------------------

MOD = 65413
N = 7
ELEM_COUNT = N * N          # 49
ENC_BLOCK_SIZE = 98         # 49 * 2

INPUT_FILE = "FLAG.PNG.enc"
OUTPUT_FILE = "FLAG.PNG"

PNG_HEADER = bytes.fromhex("89 50 4E 47 0D 0A 1A 0A")


# ============================================================
# 1. UCRT/MSVC 계열 rand() 재현
# ============================================================

class CRand:
    """
    MSVC/UCRT 계열 rand() 시퀀스를 재현하기 위한 클래스.

    C에서:
        srand(seed);
        rand();
        rand();

    와 같은 호출 순서를 Python에서도 똑같이 재현하기 위해 사용한다.

    rand() 반환값 범위:
        0 ~ 32767
    """

    def __init__(self, seed):
        # C의 unsigned int seed처럼 32비트로 제한
        self.state = seed & 0xFFFFFFFF

    def rand(self):
        # MSVC 계열 LCG
        self.state = (
            self.state * 214013 + 2531011
        ) & 0xFFFFFFFF

        return (self.state >> 16) & 0x7FFF


# ============================================================
# 2. mod 65413 행렬 곱셈
# ============================================================

def mat_mul_mod(A, B):
    """
    7x7 행렬 A, B에 대해

        C = A * B mod 65413

    을 계산한다.

    복호화에서는:
        M_i = P_i * inverse(P_(i+1))

    계산에 사용된다.
    """

    C = [[0] * N for _ in range(N)]

    for i in range(N):
        for j in range(N):
            total = 0

            for k in range(N):
                total += A[i][k] * B[k][j]

            C[i][j] = total % MOD

    return C


# ============================================================
# 3. mod 65413 역행렬
# ============================================================

def mat_inv_mod(A):
    """
    7x7 행렬 A의 역행렬을 mod 65413에서 계산한다.

    일반적인 실수(float) 역행렬이 아니라
    모든 연산을 정수 + mod 연산으로 수행한다.

    방식:
        [ A | I ]

    에 대해 Gauss-Jordan elimination을 수행하여

        [ I | A^-1 ]

    형태를 만든다.
    """

    # A를 직접 변경하지 않도록 복사
    left = [
        [x % MOD for x in row]
        for row in A
    ]

    # 단위행렬
    right = [
        [1 if i == j else 0 for j in range(N)]
        for i in range(N)
    ]

    for col in range(N):

        # ----------------------------------------------------
        # 현재 열에서 0이 아닌 pivot 찾기
        # MOD=65413은 소수이므로 0이 아닌 원소는 역원이 존재한다.
        # ----------------------------------------------------
        pivot_row = None

        for row in range(col, N):
            if left[row][col] % MOD != 0:
                pivot_row = row
                break

        if pivot_row is None:
            raise ValueError(
                f"역행렬이 존재하지 않습니다. pivot column={col}"
            )

        # pivot 행을 현재 위치로 이동
        if pivot_row != col:
            left[col], left[pivot_row] = left[pivot_row], left[col]
            right[col], right[pivot_row] = right[pivot_row], right[col]

        # ----------------------------------------------------
        # pivot을 1로 만들기
        #
        # 일반 나눗셈:
        #     x / pivot
        #
        # 이 아니라 modular inverse를 이용:
        #     x * pivot^-1 mod MOD
        # ----------------------------------------------------
        pivot = left[col][col] % MOD
        pivot_inv = pow(pivot, -1, MOD)

        left[col] = [
            (x * pivot_inv) % MOD
            for x in left[col]
        ]

        right[col] = [
            (x * pivot_inv) % MOD
            for x in right[col]
        ]

        # ----------------------------------------------------
        # 나머지 행의 현재 열 값을 0으로 제거
        # ----------------------------------------------------
        for row in range(N):
            if row == col:
                continue

            factor = left[row][col] % MOD

            if factor == 0:
                continue

            left[row] = [
                (a - factor * b) % MOD
                for a, b in zip(left[row], left[col])
            ]

            right[row] = [
                (a - factor * b) % MOD
                for a, b in zip(right[row], right[col])
            ]

    return right


# ============================================================
# 4. 암호문 98바이트 -> P_i 행렬 복원
# ============================================================

def decrypt_P_block(enc_block, rng):
    """
    sub_16A0의 마지막 XOR 단계를 되돌린다.

    원본 C 코드의 핵심:
        v6 = matrix의 특정 1바이트
        output_byte = rand() ^ v6

    단, output_byte는 _BYTE에 저장되므로 실제로는:
        output_byte = (rand() ^ v6) & 0xFF

    따라서 역연산:
        v6 = output_byte ^ (rand() & 0xFF)

    각 행렬 원소마다 하위 2바이트가 저장되므로:
        byte0 = low byte
        byte1 = high byte

    다시 정수로 합치면:
        value = byte0 | (byte1 << 8)

    결과:
        49개의 값을 7x7 행렬 P_i로 복원
    """

    if len(enc_block) != ENC_BLOCK_SIZE:
        raise ValueError("enc_block must be exactly 98 bytes")

    values = []

    for k in range(ELEM_COUNT):
        c0 = enc_block[2 * k]
        c1 = enc_block[2 * k + 1]

        # 중요:
        # rand() 전체 정수를 XOR하는 것이 아니라
        # 저장 결과가 1바이트였으므로 하위 8비트만 사용
        byte0 = c0 ^ (rng.rand() & 0xFF)
        byte1 = c1 ^ (rng.rand() & 0xFF)

        # little-endian 2바이트 -> 16비트 정수
        value = byte0 | (byte1 << 8)

        values.append(value)

    # 1차원 49개 값을 7x7로 재구성
    return [
        values[i * N:(i + 1) * N]
        for i in range(N)
    ]


# ============================================================
# 5. P_i -> 원래의 M_i 복원
# ============================================================

def recover_M_matrices(P):
    """
    분석한 관계:

        P_i
        = M_i * M_(i+1) * ... * M_(n-1)

    그리고:

        P_(i+1)
        = M_(i+1) * ... * M_(n-1)

    따라서:

        P_i = M_i * P_(i+1)

    양변 오른쪽에 inverse(P_(i+1))를 곱하면:

        M_i = P_i * inverse(P_(i+1))

    마지막 블록은 뒤에 곱할 행렬이 없으므로:

        M_(n-1) = P_(n-1)
    """

    count = len(P)

    if count == 0:
        return []

    M = [None] * count

    # 마지막 블록
    M[count - 1] = P[count - 1]

    # 뒤에서 앞으로 원래 M_i 복구
    for i in range(count - 2, -1, -1):
        inv_next = mat_inv_mod(P[i + 1])

        M[i] = mat_mul_mod(
            P[i],
            inv_next
        )

    return M


# ============================================================
# 6. M_i -> 최초 파일 바이트 복원
# ============================================================

def recover_plain_block(M, rng):
    """
    sub_1180의 최초 데이터 삽입 과정을 되돌린다.

    원본:
        matrix[x] = (rand() % 65413) ^ plain[x]

    XOR은 자기 자신이 역연산이므로:
        plain[x] = matrix[x] ^ (rand() % 65413)

    UCRT rand() <= 32767 이므로:
        rand() % 65413 == rand()

    이지만 원본 코드의 의미를 보존하기 위해
    그대로 % MOD를 적어둔다.

    주의:
    마지막 블록에서 실제 파일 데이터가 49바이트보다 짧았다면
    남은 칸은 원본 sub_1180에서 랜덤 padding이었다.
    그 부분을 XOR하면 실제 파일 바이트가 아니라 0 또는 의미 없는 값이 된다.
    """

    flat = [
        value
        for row in M
        for value in row
    ]

    result = bytearray()

    for value in flat:
        r = rng.rand() % MOD
        plain = value ^ r

        # 여기서 무조건 &0xFF로 눌러버리면
        # 복호화 실패를 숨길 수 있으므로 검사한다.
        #
        # 다만 마지막 블록 padding 부분은 예외가 될 수 있다.
        if not 0 <= plain <= 0xFF:
            # 즉시 죽이지 않고 하위 1바이트만 저장한다.
            # 디버깅이 필요하면 아래 print 주석을 해제.
            #
            # print(
            #     "[!] suspicious plain value:",
            #     plain,
            #     "matrix=",
            #     value,
            #     "rand=",
            #     r
            # )
            pass

        result.append(plain & 0xFF)

    return bytes(result)


# ============================================================
# 7. PNG IEND 기준으로 끝부분 자르기
# ============================================================

def trim_png_at_iend(data):
    """
    정상 PNG라면 마지막 청크가 IEND이다.

    IEND 청크 전체 구조:
        length  : 4 bytes = 00 00 00 00
        type    : 4 bytes = 49 45 4E 44 ("IEND")
        crc     : 4 bytes

    즉:
        00 00 00 00 49 45 4E 44 xx xx xx xx

    를 찾아 그 CRC까지 포함해서 자른다.

    찾지 못하면 원본 데이터를 그대로 반환한다.
    """

    marker = b"\x00\x00\x00\x00IEND"
    pos = data.find(marker)

    if pos == -1:
        return data

    end = pos + 12

    if end > len(data):
        return data

    return data[:end]


# ============================================================
# 8. main
# ============================================================

def main():

    # --------------------------------------------------------
    # 암호문 읽기
    # --------------------------------------------------------
    with open(INPUT_FILE, "rb") as f:
        enc = f.read()

    if len(enc) % ENC_BLOCK_SIZE != 0:
        raise ValueError(
            f"암호문 크기 {len(enc)}가 98의 배수가 아닙니다."
        )

    block_count = len(enc) // ENC_BLOCK_SIZE

    print("[+] enc size:", len(enc))
    print("[+] block count:", block_count)

    # --------------------------------------------------------
    # PNG 첫 바이트 0x89를 srand seed로 사용한다고 분석됨
    # --------------------------------------------------------
    seed = 0xFFFFFF89

    # --------------------------------------------------------
    # 암호화 실행 당시의 rand() 호출 순서 재현
    # --------------------------------------------------------
    rng = CRand(seed)

    # 1) sub_1570에서 최초 M_i 행렬들을 만들 때:
    #
    #    sub_1180(7, ..., ...)
    #
    #    하나당 총 49회의 rand()가 호출된다.
    #
    #    실제 데이터 영역:
    #        rand() ^ plain
    #
    #    나머지 padding:
    #        rand()
    #
    #    합계는 언제나 49회.
    for _ in range(block_count * ELEM_COUNT):
        rng.rand()

    # --------------------------------------------------------
    # 2) sub_16A0의 실제 호출 순서를 그대로 재현
    #
    # 중요:
    #
    # 잘못된 방식:
    #   모든 sub_12C0 rand를 먼저 소비
    #   -> 그 뒤 모든 P_i 출력 XOR
    #
    # 실제 방식:
    #
    #   i = 0:
    #       sub_12C0 반복
    #       P_0 출력 XOR 98회
    #
    #   i = 1:
    #       sub_12C0 반복
    #       P_1 출력 XOR 98회
    #
    #   ...
    #
    # 따라서 i마다 행렬곱용 rand 소비와
    # 출력 XOR 복원을 묶어서 처리해야 한다.
    # --------------------------------------------------------
    P = []

    for i in range(block_count):

        # 현재 i에서:
        #
        # j = i+1 ... block_count-1
        #
        # 만큼 sub_12C0 호출
        sub12c0_count = block_count - i - 1

        # sub_12C0 호출 1회마다:
        #
        # sub_1180(7, 0, 0)
        #
        # 가 호출되고 rand() 49회를 소비한다.
        for _ in range(sub12c0_count * ELEM_COUNT):
            rng.rand()

        # 그 직후 현재 i번째 결과 P_i를
        # 98바이트로 출력하며 rand() 98회를 사용한다.
        start = i * ENC_BLOCK_SIZE
        end = start + ENC_BLOCK_SIZE

        Pi = decrypt_P_block(
            enc[start:end],
            rng
        )

        P.append(Pi)

    print("[+] P matrices recovered")

    # --------------------------------------------------------
    # P_i -> 원래 M_i
    # --------------------------------------------------------
    M = recover_M_matrices(P)

    print("[+] M matrices recovered")

    # --------------------------------------------------------
    # 최초 M_i를 만들 때 사용했던 rand() 값을 다시 써야 함.
    #
    # srand(seed)를 다시 한 것과 같은 효과로
    # RNG를 초기 상태로 되돌린다.
    # --------------------------------------------------------
    rng_plain = CRand(seed)

    recovered = bytearray()

    for matrix in M:
        recovered.extend(
            recover_plain_block(
                matrix,
                rng_plain
            )
        )

    # --------------------------------------------------------
    # PNG header 확인
    # --------------------------------------------------------
    print(
        "[+] raw header:",
        recovered[:8].hex(" ")
    )

    if recovered[:8] == PNG_HEADER:
        print("[+] PNG header OK")
    else:
        print("[!] PNG header mismatch")
        print(
            "    expected:",
            PNG_HEADER.hex(" ")
        )

    # --------------------------------------------------------
    # 마지막 49바이트 블록의 random padding 제거를 위해
    # 정상 PNG라면 IEND 위치에서 자른다.
    # --------------------------------------------------------
    trimmed = trim_png_at_iend(bytes(recovered))

    with open(OUTPUT_FILE, "wb") as f:
        f.write(trimmed)

    print("[+] output:", OUTPUT_FILE)
    print("[+] output size:", len(trimmed))


if __name__ == "__main__":
    main()
